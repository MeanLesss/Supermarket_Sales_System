# Supermarket_Sales_System
This application can take log in authentication and sign up account for Manager and Cashier for the supermarket managerment.

#2 user autehentication
#Mananger : 
- Can add item in to the stock write to file and view all product (wriite into file product.dat)
- Can update item in the stock from file (product.dat)
- Can delete item in the stock edite file  (product.dat)
- Also create cashier account and store in to file and check the info (user.dat)
- Update cashier information from file (user.dat)
- Delete cashier account from file (user.dat)

#Cashier : 
- Can add items from the customer item using id
- Add product to cart and remove from cart
- Print out invoice with billing and update stock info (product.dat)
- ***Save all billing to file as report (report.dat)***
